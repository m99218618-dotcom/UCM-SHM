PHYS210 – UCM and SHM Interactive Simulation

OPEN LOCALLY
Double-click index.html. No software or internet connection is required.

PUBLISH THROUGH GITHUB PAGES
1. Create a public GitHub repository, e.g. phys210-ucm-shm.
2. Upload index.html to the repository root.
3. Open Settings > Pages; choose Deploy from a branch, main, /(root), Save.
4. The student link will follow the form: https://YOUR-USERNAME.github.io/phys210-ucm-shm/
   Replace YOUR-USERNAME with your GitHub username. Wait until GitHub reports deployment.
5. Paste this URL into Moodle using Add an activity or resource > URL.

You may upload index.html to Moodle as a File if your Moodle site allows HTML display, but GitHub Pages hosting is recommended.

Course: PHYS210 Physics for Teachers
Author: Dr. Mohammed Al Bahri
